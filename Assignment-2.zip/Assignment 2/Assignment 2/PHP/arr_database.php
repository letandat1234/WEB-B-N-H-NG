<?php
	$categories = array(
					array('code'=>1, 'name'=>'iPhone','description'=>'From USA v10'),
					array('code'=>2, 'name'=>'samsung','description'=>'From Korea v10'),
					array('code'=>3, 'name'=>'Oppo','description'=>'From USA v10'),
					array('code'=>4, 'name'=>'BPhone','description'=>'From VN v10')
				);

?>